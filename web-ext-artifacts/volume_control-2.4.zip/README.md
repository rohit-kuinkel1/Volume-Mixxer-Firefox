![screenshot](https://i.imgur.com/5WJa1Ku.png)
![image](https://user-images.githubusercontent.com/6486343/167278608-9cb61b61-4fd6-4ba4-a380-b8112c67eec5.png)


Now with an automatic darkmode. Now available directly through Firefox https://addons.mozilla.org/en-US/firefox/addon/volume-control-boost-volume/

Supports HTML5 video and audio only (no Flash).
